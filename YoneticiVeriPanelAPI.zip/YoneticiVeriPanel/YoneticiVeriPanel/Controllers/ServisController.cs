﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using YoneticiVeriPanel.Models;
using YoneticiVeriPanel.ViewModel;

namespace YoneticiVeriPanel.Controllers
{
    public class ServisController : ApiController
    {
        YoneticiVeriPanelEntities db = new YoneticiVeriPanelEntities();
         SonucModel sonuc = new SonucModel();

        #region Kategori
        [HttpGet]
        [Route("api/kategoriliste")]

        public List<KategoriModel> KategoriListe()
        {
            List<KategoriModel> liste = db.Kategori.Select(x => new KategoriModel()
            {
                KategoriId = x.KategoriId,
                KategoriAdi = x.KategoriAdi,
                KategoriMakaleSay = x.Makale.Count

            }).ToList();

            return liste;
        }

        [HttpGet]
        [Route("api/kategoribyid/{katId}")]
        public KategoriModel KategoriById(int katId)
        {
            KategoriModel kayit = db.Kategori.Where(s => s.KategoriId == katId).Select(x => new KategoriModel()
            {
                KategoriId = x.KategoriId,
                KategoriAdi = x.KategoriAdi,
                KategoriMakaleSay = x.Makale.Count
            }).SingleOrDefault();
            return kayit;
        }
        [HttpPost]
        [Route("api/kategoriekle")]

        public SonucModel KategoriEkle(KategoriModel model)
        {
            if (db.Kategori.Count(s => s.KategoriAdi == model.KategoriAdi) > 0)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Girilen Kategori Adi Kayıtlıdır ";
                return sonuc;
            }
            Kategori yeni = new Kategori();
            yeni.KategoriAdi = model.KategoriAdi;
            db.Kategori.Add(yeni);
            db.SaveChanges();


            sonuc.islem = true;
            sonuc.mesaj = "Kategori Eklendi";
            return sonuc;
        }
        [HttpPut]
        [Route("api/kategoriduzenle")]
        public SonucModel KategoriDuzenle(KategoriModel model)
        {
            Kategori kayit = db.Kategori.Where(s => s.KategoriId == model.KategoriId).SingleOrDefault();
            if (kayit == null)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Kayıt Bulunamadı!";
                return sonuc;
            }

            kayit.KategoriAdi = model.KategoriAdi;
            db.SaveChanges();

            sonuc.islem = true;
            sonuc.mesaj = "Kategori Düzenlendi";

            return sonuc;
        }

        [HttpDelete]
        [Route("api/kategorisil/{katId}")]
        public SonucModel KategoriSil(int katId)
        {
            Kategori kayit = db.Kategori.Where(s => s.KategoriId == katId).SingleOrDefault();
            if (kayit == null)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Kayıt Bulunamadı!";
                return sonuc;
            }
            if (db.Makale.Count(s => s.KategoriId == katId) > 0)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Üzerinde Makale Kayıtlı Olan Kategori Silinemez!";
                return sonuc;
            }
            db.Kategori.Remove(kayit);
            db.SaveChanges();

            sonuc.islem = true;
            sonuc.mesaj = "Kategori Silindi";
            return sonuc;
        }
        #endregion

        #region Makale

        [HttpGet]
        [Route("api/makaleliste")]
        public List<MakaleModel> MakaleListe()
        {
            List<MakaleModel> liste = db.Makale.Select(x => new MakaleModel()
            {
                MakaleId = x.MakaleId,
                Baslik = x.Baslik,
                Icerik = x.Icerik,
                Foto = x.Foto,
                Tarih = x.Tarih,
                KategoriAdi = x.Kategori.KategoriAdi,
                UyeKadi = x.Uye.KullaniciAdi,
                KategoriId = (int)x.KategoriId,


            }).ToList();
            return liste;
        }
        [HttpGet]
        [Route("api/makalelistesoneklenenler/{s}")]
        public List<MakaleModel> MakaleListeSonEklenenler(int s)
        {
            List<MakaleModel> liste = db.Makale.OrderByDescending(o => o.MakaleId).Take(s).Select(x => new MakaleModel()
            {
                MakaleId = x.MakaleId,
                Baslik = x.Baslik,
                Icerik = x.Icerik,
                Foto = x.Foto,
                Tarih = x.Tarih,
                KategoriAdi = x.Kategori.KategoriAdi,
                UyeKadi = x.Uye.KullaniciAdi,
                KategoriId = (int)x.KategoriId,


            }).ToList();
            return liste;
        }
        [HttpGet]
        [Route("api/makalelistebykatid/{katId}")]
        public List<MakaleModel> MakaleListeByKatId(int katId)
        {
            List<MakaleModel> liste = db.Makale.Where(s => s.KategoriId == katId).Select(x => new MakaleModel()
            {
                MakaleId = x.MakaleId,
                Baslik = x.Baslik,
                Icerik = x.Icerik,
                Foto = x.Foto,
                Tarih = x.Tarih,
                KategoriAdi = x.Kategori.KategoriAdi,
                UyeKadi = x.Uye.KullaniciAdi,
                KategoriId = (int)x.KategoriId,


            }).ToList();
            return liste;
        }
        [HttpGet]
        [Route("api/makalelistebyuyeid/{uyeId}")]
        public List<MakaleModel> MakaleListeByUyeId(int uyeId)
        {
            List<MakaleModel> liste = db.Makale.Where(s => s.UyeId == uyeId).Select(x => new MakaleModel()
            {
                MakaleId = x.MakaleId,
                Baslik = x.Baslik,
                Icerik = x.Icerik,
                Foto = x.Foto,
                Tarih = x.Tarih,
                KategoriAdi = x.Kategori.KategoriAdi,
                UyeKadi = x.Uye.KullaniciAdi,
                KategoriId = (int)x.KategoriId,


            }).ToList();
            return liste;
        }

        [HttpGet]
        [Route("api/makalebyid/{makaleId}")]
        public MakaleModel MakaleById(int makaleId)
        {
            MakaleModel kayit = db.Makale.Where(s => s.MakaleId == makaleId).Select(x => new MakaleModel()
            {
                MakaleId = x.MakaleId,
                Baslik = x.Baslik,
                Icerik = x.Icerik,
                Foto = x.Foto,
                Tarih = x.Tarih,
                KategoriAdi = x.Kategori.KategoriAdi,
                UyeKadi = x.Uye.KullaniciAdi,
                KategoriId= (int)x.KategoriId,

            }).SingleOrDefault();

            return kayit;
        }

        [HttpPost]
        [Route("api/makaleekle")]
        public SonucModel MakaleEkle(MakaleModel model)
        {
            if (db.Makale.Count(s => s.Baslik == model.Baslik) > 0)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Girilen Makale Başlığı Kayıtlıdır!";
                return sonuc;
            }

            Makale yeni = new Makale();
            yeni.Baslik = model.Baslik;
            yeni.Icerik = model.Icerik;
            yeni.KategoriId = model.KategoriId;
            yeni.Foto = model.Foto;
            yeni.Okunma = model.Okunma;
            yeni.Tarih = model.Tarih;
            yeni.UyeId = model.UyeId;
            db.Makale.Add(yeni);
            db.SaveChanges();

            sonuc.islem = true;
            sonuc.mesaj = "Makale Eklendi";
            return sonuc;
        }

        [HttpPut]
        [Route("api/makaleduzenle")]
        public SonucModel MakaleDuzenle(MakaleModel model)
        {

            Makale kayit = db.Makale.Where(s => s.MakaleId == model.MakaleId).SingleOrDefault();

            if (kayit == null)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Kayıt Bulunamadı!";
                return sonuc;
            }
            kayit.Baslik = model.Baslik;
            kayit.Icerik = model.Icerik;
            kayit.KategoriId = model.KategoriId;
            kayit.Foto = model.Foto;
            kayit.Okunma = model.Okunma;

            db.SaveChanges();

            sonuc.islem = true;
            sonuc.mesaj = "Makale Düzenlendi";

            return sonuc;
        }

        [HttpDelete]
        [Route("api/makalesil/{makaleId}")]
        public SonucModel MakaleSil(int makaleId)
        {
            Makale kayit = db.Makale.Where(s => s.MakaleId == makaleId).SingleOrDefault();

            if (kayit == null)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Kayıt Bulunamadı!";
                return sonuc;
            }

            if (db.Yorum.Count(s => s.MakaleId == makaleId) > 0)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Üzerinde Yorum Kayıtlı Makale Silinemez!";
                return sonuc;
            }
            db.Makale.Remove(kayit);
            db.SaveChanges();

            sonuc.islem = true;
            sonuc.mesaj = "Makale Silindi";
            return sonuc;
        }
        #endregion

        #region Üye


        [HttpGet]
        [Route("api/uyeliste")]
        public List<UyeModel> UyeListe()
        {
            List<UyeModel> liste = db.Uye.Select(x => new UyeModel()
            {
                UyeId = x.UyeId,
                AdSoyad = x.AdSoyad,
                KullaniciAdi = x.KullaniciAdi,
                Email = x.Email,
                Sifre = x.Sifre,
                Foto = x.Foto,
                UyeAdmin = x.UyeAdmin
            }).ToList();

            return liste;
        }

        [HttpGet]
        [Route("api/uyebyid/{uyeId}")]
        public UyeModel UyeById(int uyeId)
        {
            UyeModel kayit = db.Uye.Where(s => s.UyeId == uyeId).Select(x => new UyeModel()
            {
                UyeId = x.UyeId,
                AdSoyad = x.AdSoyad,
                KullaniciAdi = x.KullaniciAdi,
                Email = x.Email,
                Sifre = x.Sifre,
                Foto = x.Foto,
                UyeAdmin = x.UyeAdmin

            }).SingleOrDefault();

            return kayit;
        }


        [HttpPost]
        [Route("api/uyeekle")]
        public SonucModel UyeEkle(UyeModel model)
        {
            if (db.Uye.Count(s => s.KullaniciAdi == model.KullaniciAdi || s.Email == model.Email) > 0)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Girilen Kullanıcı Adı veya E-Posta Adresi Kayıtlıdır!";
                return sonuc;
            }

            Uye yeni = new Uye();
            yeni.UyeId = model.UyeId;
            yeni.AdSoyad = model.AdSoyad;
            yeni.KullaniciAdi = model.KullaniciAdi;
            yeni.Email = model.Email;
            yeni.Sifre = model.Sifre;
            yeni.Foto = model.Foto;
            yeni.UyeAdmin = model.UyeAdmin;

            db.Uye.Add(yeni);
            db.SaveChanges();

            sonuc.islem = true;
            sonuc.mesaj = "Üye Eklendi";
            return sonuc;
        }


        [HttpPut]
        [Route("api/uyeduzenle")]
        public SonucModel UyeDuzenle(UyeModel model)
        {
            Uye kayit = db.Uye.Where(s => s.UyeId == model.UyeId).SingleOrDefault();
            if (kayit == null)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Kayıt Bulunamadı";
                return sonuc;
            }
            kayit.UyeId = model.UyeId;
            kayit.AdSoyad = model.AdSoyad;
            kayit.KullaniciAdi = model.KullaniciAdi;
            kayit.Email = model.Email;
            kayit.Sifre = model.Sifre;
            kayit.Foto = model.Foto;
            kayit.UyeAdmin = model.UyeAdmin;
            db.SaveChanges();

            sonuc.islem = true;
            sonuc.mesaj = "Üye Düzenlendi";
            return sonuc;
        }

        [HttpDelete]
        [Route("api/uyesil/{uyeId}")]
        public SonucModel UyeSil(int uyeId)
        {
            Uye kayit = db.Uye.Where(s => s.UyeId == uyeId).SingleOrDefault();
            if (kayit == null)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Kayıt Bulunamadı";
                return sonuc;
            }

            if (db.Makale.Count(s => s.UyeId == uyeId) > 0)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Makale Kaydı Olan Üye Silinemez!";
                return sonuc;
            }

            if (db.Yorum.Count(s => s.UyeId == uyeId) > 0)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Yorum Kaydı Olan Üye Silinemez!";
                return sonuc;
            }

            db.Uye.Remove(kayit);
            db.SaveChanges();
            sonuc.islem = true;
            sonuc.mesaj = "Üye Silindi";
            return sonuc;
        }
        #endregion

        #region Yorum

        [HttpGet]
        [Route("api/yorumliste")]
        public List<YorumModel> YorumListe()
        {
            List<YorumModel> liste = db.Yorum.Select(x => new YorumModel()
            {

                YorumId = x.YorumId,
                YorumIcerik = x.YorumIcerik,
                Tarih = x.Tarih,
                MakaleId = x.MakaleId,
                MakaleBaslik = x.Makale.Baslik,
                UyeId = x.UyeId,
                KullaniciAdi = x.Uye.KullaniciAdi

            }).ToList();
            return liste;

        }
        [HttpGet]
        [Route("api/yorumlistesoneklenenler/{s}")]
        public List<YorumModel> YorumListeSonEklenenler(int s)
        {
            List<YorumModel> liste = db.Yorum.OrderByDescending(o => o.YorumId).Take(s).Select(x => new YorumModel()
            {

                YorumId = x.YorumId,
                YorumIcerik = x.YorumIcerik,
                Tarih = x.Tarih,
                MakaleId = x.MakaleId,
                MakaleBaslik = x.Makale.Baslik,
                UyeId = x.UyeId,
                KullaniciAdi = x.Uye.KullaniciAdi

            }).ToList();
            return liste;

        }
        [HttpGet]
        [Route("api/yorumlistebymakaleid/{makaleId}")]
        public List<YorumModel> YorumListeByMakaleId(int makaleId)
        {
            List<YorumModel> liste = db.Yorum.Where(s => s.MakaleId == makaleId).Select(x => new YorumModel()
            {

                YorumId = x.YorumId,
                YorumIcerik = x.YorumIcerik,
                Tarih = x.Tarih,
                MakaleId = x.MakaleId,
                MakaleBaslik = x.Makale.Baslik,
                UyeId = x.UyeId,
                KullaniciAdi = x.Uye.KullaniciAdi

            }).ToList();
            return liste;

        }
        [HttpGet]
        [Route("api/yorumlistebyuyeid/{uyeId}")]
        public List<YorumModel> YorumListeByUyeId(int uyeId)
        {
            List<YorumModel> liste = db.Yorum.Where(s => s.UyeId == uyeId).Select(x => new YorumModel()
            {

                YorumId = x.YorumId,
                YorumIcerik = x.YorumIcerik,
                Tarih = x.Tarih,
                MakaleId = x.MakaleId,
                MakaleBaslik = x.Makale.Baslik,
                UyeId = x.UyeId,
                KullaniciAdi = x.Uye.KullaniciAdi
                

            }).ToList();
            return liste;

        }
        [HttpGet]
        [Route("api/yorumbyid/{yorumId}")]
        public YorumModel YorumById(int yorumId)
        {
            YorumModel kayit = db.Yorum.Where(s => s.YorumId == yorumId).Select(x => new YorumModel()
            {

                YorumId = x.YorumId,
                YorumIcerik = x.YorumIcerik,
                Tarih = x.Tarih,
                MakaleId = x.MakaleId,
                MakaleBaslik = x.Makale.Baslik,
                UyeId = x.UyeId,
                KullaniciAdi = x.Uye.KullaniciAdi

            }).SingleOrDefault();

            return kayit;

        }

        [HttpPost]
        [Route("api/yorumekle")]
        public SonucModel YorumEkle(YorumModel model)
        {
            if (db.Yorum.Count(s => s.YorumIcerik == model.YorumIcerik && s.MakaleId == model.MakaleId && s.UyeId == model.UyeId) > 0)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Aynı Kişi, Aynı Makaleye Aynı Yorumu Yapamaz!";
                return sonuc;
            }

            Yorum yeni = new Yorum();
            yeni.YorumIcerik = model.YorumIcerik;
            yeni.Tarih = model.Tarih;
            yeni.UyeId = model.UyeId;
            yeni.MakaleId = model.MakaleId;

            db.Yorum.Add(yeni);
            db.SaveChanges();

            sonuc.islem = true;
            sonuc.mesaj = "Yorum Eklendi";

            return sonuc;
        }

        [HttpPut]
        [Route("api/yorumduzenle")]
        public SonucModel YorumDuzenle(YorumModel model)
        {
            Yorum kayit = db.Yorum.Where(s => s.YorumId == model.YorumId).SingleOrDefault();

            if (kayit == null)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Kayıt Bulunamadı";
                return sonuc;
            }

            kayit.YorumIcerik = model.YorumIcerik;
            kayit.Tarih = model.Tarih;
            kayit.UyeId = model.UyeId;
            kayit.MakaleId = model.MakaleId;


            db.SaveChanges();

            sonuc.islem = true;
            sonuc.mesaj = "Yorum Düzenlendi";
            return sonuc;
        }

        [HttpDelete]
        [Route("api/yorumsil/{yorumId}")]
        public SonucModel YorumSil(int yorumId)
        {

            Yorum kayit = db.Yorum.Where(s => s.YorumId == yorumId).SingleOrDefault();

            if (kayit == null)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Kayıt Bulunamadı";
                return sonuc;
            }

            db.Yorum.Remove(kayit);

            db.SaveChanges();

            sonuc.islem = true;
            sonuc.mesaj = "Yorum Silindi";
            return sonuc;
        }
        #endregion


        #region Makale

        [HttpGet]
        [Route("api/duyuruliste")]
        public List<DuyuruModel> DuyuruListe()
        {
            List<DuyuruModel> liste = db.Duyuru.Select(x => new DuyuruModel()
            {
                DuyuruId=x.DuyuruId,
                DuyuruBaslik=x.DuyuruBaslik,
                DuyuruIcerik=x.DuyuruIcerik,
                DuyuruFoto=x.DuyuruFoto,
                DuyuruTarih=x.DuyuruTarih,
                KategoriAdi = x.Kategori.KategoriAdi,
                UyeKadi = x.Uye.KullaniciAdi

            }).ToList();
            return liste;
        }
        [HttpGet]
        [Route("api/duyurulistesoneklenenler/{s}")]
        public List<DuyuruModel> DuyuruListeSonEklenenler(int s)
        {
            List<DuyuruModel> liste = db.Duyuru.OrderByDescending(o => o.DuyuruId).Take(s).Select(x => new DuyuruModel()
            {
                DuyuruId = x.DuyuruId,
                DuyuruBaslik = x.DuyuruBaslik,
                DuyuruIcerik = x.DuyuruIcerik,
                DuyuruFoto = x.DuyuruFoto,
                DuyuruTarih = x.DuyuruTarih,
                KategoriAdi = x.Kategori.KategoriAdi,
                UyeKadi = x.Uye.KullaniciAdi,
                KategoriId = x.KategoriId,


            }).ToList();
            return liste;
        }
        [HttpGet]
        [Route("api/duyurulistebykatid/{katId}")]
        public List<DuyuruModel> DuyuruListeByKatId(int katId)
        {
            List<DuyuruModel> liste = db.Duyuru.Where(s => s.KategoriId == katId).Select(x => new DuyuruModel()
            {
                DuyuruId = x.DuyuruId,
                DuyuruBaslik = x.DuyuruBaslik,
                DuyuruIcerik = x.DuyuruIcerik,
                DuyuruFoto = x.DuyuruFoto,
                DuyuruTarih = x.DuyuruTarih,
                KategoriAdi = x.Kategori.KategoriAdi,
                UyeKadi = x.Uye.KullaniciAdi,
                KategoriId = x.KategoriId,

            }).ToList();
            return liste;
        }
        [HttpGet]
        [Route("api/duyurulistebyuyeid/{uyeId}")]
        public List<DuyuruModel> DuyuruListeByUyeId(int uyeId)
        {
            List<DuyuruModel> liste = db.Duyuru.Where(s => s.UyeId == uyeId).Select(x => new DuyuruModel()
            {
                DuyuruId = x.DuyuruId,
                DuyuruBaslik = x.DuyuruBaslik,
                DuyuruIcerik = x.DuyuruIcerik,
                DuyuruFoto = x.DuyuruFoto,
                DuyuruTarih = x.DuyuruTarih,
                KategoriAdi = x.Kategori.KategoriAdi,
                UyeKadi = x.Uye.KullaniciAdi,
                KategoriId = x.KategoriId,


            }).ToList();
            return liste;
        }

        [HttpGet]
        [Route("api/duyurubyid/{duyuruleId}")]
        public DuyuruModel DuyuruById(int duyuruId)
        {
            DuyuruModel kayit = db.Duyuru.Where(s => s.DuyuruId == duyuruId).Select(x => new DuyuruModel()
            {
                DuyuruId = x.DuyuruId,
                DuyuruBaslik = x.DuyuruBaslik,
                DuyuruIcerik = x.DuyuruIcerik,
                DuyuruFoto = x.DuyuruFoto,
                DuyuruTarih = x.DuyuruTarih,
                KategoriAdi = x.Kategori.KategoriAdi,
                UyeKadi = x.Uye.KullaniciAdi,
                KategoriId = x.KategoriId,


            }).SingleOrDefault();

            return kayit;
        }

        [HttpPost]
        [Route("api/duyuruekle")]
        public SonucModel DuyuruEkle(DuyuruModel model)
        {
            if (db.Duyuru.Count(s => s.DuyuruBaslik == model.DuyuruBaslik) > 0)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Girilen Makale Başlığı Kayıtlıdır!";
                return sonuc;
            }
            Duyuru yeni = new Duyuru();
            yeni.DuyuruBaslik = model.DuyuruBaslik;
            yeni.DuyuruIcerik = model.DuyuruIcerik;
            yeni.DuyuruTarih = model.DuyuruTarih;
            yeni.KategoriId = model.KategoriId;
            yeni.DuyuruTarih = model.DuyuruTarih;
            yeni.DuyuruOkunma = model.DuyuruOkunma;
            yeni.UyeId = model.UyeId;
            db.Duyuru.Add(yeni);
            db.SaveChanges();

            sonuc.islem = true;
            sonuc.mesaj = "Duyuru Eklendi";
            return sonuc;
        }

        [HttpPut]
        [Route("api/duyuruduzenle")]
        public SonucModel DuyuruDuzenle(DuyuruModel model)
        {

            Duyuru kayit = db.Duyuru.Where(s => s.DuyuruId == model.DuyuruId).SingleOrDefault();

            if (kayit == null)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Kayıt Bulunamadı!";
                return sonuc;
            }

            kayit.DuyuruBaslik = model.DuyuruBaslik;
            kayit.DuyuruIcerik = model.DuyuruIcerik;
            kayit.DuyuruTarih = model.DuyuruTarih;
            kayit.KategoriId = model.KategoriId;
            kayit.DuyuruTarih = model.DuyuruTarih;
            kayit.DuyuruOkunma = model.DuyuruOkunma;
            kayit.UyeId = model.UyeId;
            db.Duyuru.Add(kayit);
            db.SaveChanges();

        

            sonuc.islem = true;
            sonuc.mesaj = "Makale Düzenlendi";

            return sonuc;
        }

        [HttpDelete]
        [Route("api/duyurusil/{duyuruId}")]
        public SonucModel DuyuruSil(int duyuruId)
        {
            Duyuru kayit = db.Duyuru.Where(s => s.DuyuruId == duyuruId).SingleOrDefault();

            if (kayit == null)
            {
                sonuc.islem = false;
                sonuc.mesaj = "Kayıt Bulunamadı!";
                return sonuc;
            }
            db.Duyuru.Remove(kayit);
            db.SaveChanges();

            sonuc.islem = true;
            sonuc.mesaj = "Makale Silindi";
            return sonuc;
        }
        #endregion
    }
}
