﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using YoneticiVeriPanel.Models;
using YoneticiVeriPanel.ViewModel;

namespace YoneticiVeriPanel.Auth
{
    public class uyeService
    {
        YoneticiVeriPanelEntities db = new YoneticiVeriPanelEntities();
        public UyeModel UyeOturumAc(string kadi, string parola)
        {
            UyeModel uye = db.Uye.Where(s => s.KullaniciAdi == kadi && s.Sifre == parola).Select(x => new UyeModel()
            {
                UyeId = x.UyeId,
                AdSoyad = x.AdSoyad,
                KullaniciAdi = x.KullaniciAdi,
                Email = x.Email,
                Sifre = x.Sifre,
                Foto = x.Foto,
                UyeAdmin = x.UyeAdmin

            }).SingleOrDefault();
            return uye;
        }
    }
}