﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace YoneticiVeriPanel.ViewModel
{
    public class KategoriModel
    {

        public int KategoriId { get; set; }
        public string KategoriAdi { get; set; }
        public int KategoriMakaleSay { get; set; }
        public int KategoriDuyuruSay { get; set; }

    }
}