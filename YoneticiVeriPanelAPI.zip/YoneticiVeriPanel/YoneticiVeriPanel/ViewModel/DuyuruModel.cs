﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace YoneticiVeriPanel.ViewModel
{
    public class DuyuruModel
    {

        public int DuyuruId { get; set; }
        public string DuyuruBaslik { get; set; }
        public string DuyuruIcerik { get; set; }
        public string DuyuruFoto { get; set; }
        public Nullable<System.DateTime> DuyuruTarih { get; set; }
        public int KategoriId { get; set; }
        public int UyeId { get; set; }
        public int DuyuruOkunma { get; set; }
        public string UyeKadi { get; set; }
        public string KategoriAdi { get; set; }
        public string KullaniciAdi { get; internal set; }
    }
}