import { Kategori } from 'src/app/models/Kategori';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ApiService } from 'src/app/services/api.service';
import { BreakpointObserver, Breakpoints } from '@angular/cdk/layout';
import { Observable } from 'rxjs';
import { map, shareReplay } from 'rxjs/operators';

@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
  kadi: string;
  kategoriler: Kategori[];
  isHandset$: Observable<boolean> = this.breakpointObserver.observe(Breakpoints.Handset)
    .pipe(
      map(result => result.matches),
      shareReplay()
    );
  @Output() toggleSideBarForMe: EventEmitter<any> = new EventEmitter();

  constructor(
    private breakpointObserver: BreakpointObserver,
    public apiServis: ApiService
    ) { }
    ngOnInit(): void {
      this.KategoriListe();
      if (this.apiServis.oturumKontrol) {
        this.kadi = localStorage.getItem("kadi");
      }
    }
  
    KategoriListe() {
      this.apiServis.KategoriListe().subscribe((d: Kategori[]) => {
        this.kategoriler = d;
      });
    }
  
    OturumKapat() {
      localStorage.clear();
      location.href = "/";
    }

  toggleSideBar() {
    this.toggleSideBarForMe.emit();
    setTimeout(() => {
      window.dispatchEvent(
        new Event('resize')
      );
    }, 300);
  }

}
