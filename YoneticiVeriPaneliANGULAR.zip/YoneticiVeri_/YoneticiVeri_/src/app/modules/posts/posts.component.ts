import { ApiService } from 'src/app/services/api.service';
import { Makale } from './../../models/Makale';
import { Component, OnInit } from '@angular/core';
import { Kategori } from 'src/app/models/Kategori';
import { Duyuru } from 'src/app/models/Duyuru';
@Component({
  selector: 'app-posts',
  templateUrl: './posts.component.html',
  styleUrls: ['./posts.component.scss']
})
export class PostsComponent implements OnInit {
  makaleler: Makale[];
  duyurular:Duyuru[];
  kategoriler:Kategori[];
  constructor(
    public apiServis: ApiService
  ) { }

  ngOnInit() {
    this.SonEklenenMakaleler();
    this.SonEklenenDuyurular();
  }
  SonEklenenMakaleler() {
    this.apiServis.MakaleListeSonEklenenler(10).subscribe((d: Makale[]) => {
      this.makaleler = d;
    });
  }
  SonEklenenDuyurular() {
    this.apiServis.DuyuruListeSonEklenenler(10).subscribe((d: Duyuru[]) => {
      this.duyurular = d;
    });
  }

}