import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DefaultComponent } from './layouts/default/default.component';
import { DashboardComponent } from './modules/dashboard/dashboard.component';
import { PostsComponent } from './modules/posts/posts.component';
import { DuyuruComponent } from './components/duyuru/duyuru.component';
import { AdminDuyuruComponent } from './components/admin/admin-duyuru/admin-duyuru.component';
import { UyemakaleComponent } from './components/uyemakale/uyemakale.component';
import { KategoriComponent } from './components/kategori/kategori.component';
import { MakaleComponent } from './components/makale/makale.component';
import { AuthGuard } from './services/AuthGuard';
import { AdminUyeComponent } from './components/admin/admin-uye/admin-uye.component';
import { AdminMakaleComponent } from './components/admin/admin-makale/admin-makale.component';
import { AdminKategoriComponent } from './components/admin/admin-kategori/admin-kategori.component';
import { AdminComponent } from './components/admin/admin/admin.component';
import { LoginComponent } from './components/login/login.component';
import { AdminYorumComponent } from './components/admin/admin-yorum/admin-yorum.component';
const routes: Routes = [{
  path: '', 
  component: DefaultComponent,
  children: 
  [
    {
    path: '',
    component: DashboardComponent
  },
 {
    path: 'posts',
    component: PostsComponent
  },
  {
    path: 'login',
    component: LoginComponent
  },
  {
    path: 'makale/:makaleId',
    component: MakaleComponent
  },
  {
    path: 'kategori/:katId',
    component: KategoriComponent
  },
  {
    path: 'uyemakale/:uyeId',
    component: UyemakaleComponent
  },
  {
    path: 'admin/kategori',
    component: AdminKategoriComponent,
    canActivate: [AuthGuard],
    data: {
      yetkiler: ["Admin","Uye"],
      gerigit: "/login"
    }
  },
  {
    path: 'admin/makale',
    component: AdminMakaleComponent
  }
  , {
    path: 'admin/makale/:katId',
    component: AdminMakaleComponent
  },
  {
    path: 'admin/uye',
    component: AdminUyeComponent
  },
  {
    path: 'admin/duyuru',
    component: AdminDuyuruComponent
  },
  {
    path: 'admin/duyuru/:katId',
    component: AdminDuyuruComponent
  },
  {
    path: 'duyuru/duyurId',
    component: DuyuruComponent
  },
  {
    path: 'admin/yorum',
    component: AdminYorumComponent
  },
  {
    path: 'admin/yorum/:katId',
    component: AdminYorumComponent
  },

]
  
}];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
