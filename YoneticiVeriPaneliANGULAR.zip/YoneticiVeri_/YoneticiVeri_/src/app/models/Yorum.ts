export class Yorum {
    YorumId: number;
    YorumAdi: string;
    YorumIcerik: string;
    UyeId: number;
    KullaniciAdi: string;
    MakaleId: number;
    MakaleBaslik: string;
    Tarih: Date;
}