export class Duyuru{
    DuyuruId:number;
    DuyuruBaslik:string;
    DuyuruIcerik:string;
    DuyuruTarih:Date;
    KategoriId:number;
    YazarId:number;
    DuyuruOkunma: number;
    UyeId: number;

}