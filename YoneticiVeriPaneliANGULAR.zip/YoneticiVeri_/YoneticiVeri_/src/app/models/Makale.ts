export class Makale {
    MakaleId: number;
    Baslik: string;
    Icerik: string;
    Foto: string;
    Tarih: Date;
    KategoriId: number;
    KategoriAdi: string;
    UyeId: number;
    UyeKadi: string;
    Okunma: number;
}