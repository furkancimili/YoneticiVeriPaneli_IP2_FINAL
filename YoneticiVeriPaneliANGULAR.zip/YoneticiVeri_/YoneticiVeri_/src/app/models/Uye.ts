export class Uye {
    UyeId: number;
    KullaniciAdi: string;
    Email: string;
    Sifre: string;
    AdSoyad: string;
    Foto: string;
    UyeAdmin: number;
}