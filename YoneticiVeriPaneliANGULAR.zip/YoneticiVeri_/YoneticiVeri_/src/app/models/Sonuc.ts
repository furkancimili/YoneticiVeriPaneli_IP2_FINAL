export class Sonuc {
    islem: boolean;
    mesaj: string;
}