export class Kategori {
    KategoriId: number;
    KategoriAdi: string;
    KategoriMakaleSay: number;
    KategorDuyuruSay: number;

}