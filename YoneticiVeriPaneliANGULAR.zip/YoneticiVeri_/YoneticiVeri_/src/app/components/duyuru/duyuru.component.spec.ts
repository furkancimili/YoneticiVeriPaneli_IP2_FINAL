/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { DuyuruComponent } from './duyuru.component';

describe('DuyuruComponent', () => {
  let component: DuyuruComponent;
  let fixture: ComponentFixture<DuyuruComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DuyuruComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DuyuruComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
