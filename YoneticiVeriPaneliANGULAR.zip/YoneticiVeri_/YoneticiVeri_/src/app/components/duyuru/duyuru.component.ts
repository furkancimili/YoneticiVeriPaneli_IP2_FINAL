import { Duyuru } from './../../models/Duyuru';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { ApiService } from 'src/app/services/api.service';
import { Kategori } from 'src/app/models/Kategori';
@Component({
  selector: 'app-duyuru',
  templateUrl: './duyuru.component.html',
  styleUrls: ['./duyuru.component.scss']
})
export class DuyuruComponent implements OnInit {
  katId: number;
  kat: Kategori;
  duyurular: Duyuru[];
  constructor(
    public apiServis: ApiService,
    public route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.route.params.subscribe(p => {
      if (p.katId) {
        this.katId = p.katId;
        this.DuyuruListeByKatId();
        this.KategoriById();
      }
    });
  }
  KategoriById() {
    this.apiServis.KategoriById(this.katId).subscribe((d: Kategori) => {
      this.kat = d;
    });
  }
  DuyuruListeByKatId() {
    this.apiServis.DuyuruListeByKatId(this.katId).subscribe((d: Duyuru[]) => {
      this.duyurular = d;
    });
  }
}

