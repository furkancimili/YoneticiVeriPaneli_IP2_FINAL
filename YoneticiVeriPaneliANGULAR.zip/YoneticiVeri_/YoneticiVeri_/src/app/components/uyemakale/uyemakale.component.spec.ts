/* tslint:disable:no-unused-variable */
import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { DebugElement } from '@angular/core';

import { UyemakaleComponent } from './uyemakale.component';

describe('UyemakaleComponent', () => {
  let component: UyemakaleComponent;
  let fixture: ComponentFixture<UyemakaleComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ UyemakaleComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(UyemakaleComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
