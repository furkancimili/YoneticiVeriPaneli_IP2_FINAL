import { Yorum } from './../../../models/Yorum';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { FormGroup,FormBuilder } from '@angular/forms';
import { Component, Inject, OnInit } from '@angular/core';
import { Kategori } from 'src/app/models/Kategori';

@Component({
  selector: 'app-yorum-dialog',
  templateUrl: './yorum-dialog.component.html',
  styleUrls: ['./yorum-dialog.component.scss']
})
export class YorumDialogComponent implements OnInit {
  dialogBaslik: string;
  islem: string;
  yeniKayit: Yorum;
  frm: FormGroup;
  constructor(
    public dialogRef: MatDialogRef<YorumDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public frmBuild: FormBuilder
  ) {
    this.islem = data.islem;

    if (this.islem == 'ekle') {
      this.dialogBaslik = "Yorum Ekle";
      this.yeniKayit = new Yorum();
    }
    if (this.islem == 'duzenle') {
      this.dialogBaslik = "Yorum Düzenle";
      this.yeniKayit = data.kayit;
    }
    this.frm = this.FormOlustur();
  }

  ngOnInit() {
  }

  FormOlustur() {
    return this.frmBuild.group({
      YorumAdi: [this.yeniKayit.YorumIcerik]
    });
  }
}

