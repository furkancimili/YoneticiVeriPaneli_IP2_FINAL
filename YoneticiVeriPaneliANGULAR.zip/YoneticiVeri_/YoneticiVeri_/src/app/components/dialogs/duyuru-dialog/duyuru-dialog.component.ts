import { ApiService } from 'src/app/services/api.service';
import { Kategori } from './../../../models/Kategori';
import { MatDialogRef,MAT_DIALOG_DATA } from '@angular/material/dialog';
import { Duyuru } from './../../../models/Duyuru';
import { Component, OnInit,Inject } from '@angular/core';
import { FormGroup,FormBuilder } from '@angular/forms';
@Component({
  selector: 'app-duyuru-dialog',
  templateUrl: './duyuru-dialog.component.html',
  styleUrls: ['./duyuru-dialog.component.scss']
})
export class DuyuruDialogComponent implements OnInit {
  dialogBaslik: string;
  islem: string;
  yeniKayit: Duyuru;
  frm: FormGroup;
  kategoriler: Kategori[];
  Jconfig = {};
  constructor(
    public dialogRef: MatDialogRef<DuyuruDialogComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any,
    public frmBuild: FormBuilder,
    public apiServis: ApiService
  ) {
    this.islem = data.islem;

    if (this.islem == 'ekle') {
      this.dialogBaslik = "Duyuru Ekle";
      this.yeniKayit = new Duyuru();
    }
    if (this.islem == 'duzenle') {
      this.dialogBaslik = "Duyuru Düzenle";
      this.yeniKayit = data.kayit;
    }
    if (this.islem == 'detay') {
      this.dialogBaslik = "Duyuru Detay";
      this.yeniKayit = data.kayit;
    }
    this.frm = this.FormOlustur();
  }

  ngOnInit() {
    this.KategoriListele();
  }

  KategoriListele() {
    this.apiServis.KategoriListe().subscribe((d: Kategori[]) => {
      this.kategoriler = d;
    });
  }

  FormOlustur() {
    return this.frmBuild.group({
      DuyuruBaslik: [this.yeniKayit.DuyuruBaslik],
      KategoriId: [this.yeniKayit.KategoriId],
      DuyuruIcerik: [this.yeniKayit.DuyuruIcerik],
    });
  }
}
