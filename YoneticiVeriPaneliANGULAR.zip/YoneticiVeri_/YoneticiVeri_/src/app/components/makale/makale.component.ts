import { Sonuc } from './../../models/Sonuc';
import { Uye } from './../../models/Uye';
import { Yorum } from './../../models/Yorum';
import { Makale } from './../../models/Makale';
import { ApiService } from 'src/app/services/api.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-makale',
  templateUrl: './makale.component.html',
  styleUrls: ['./makale.component.css']
})
export class MakaleComponent implements OnInit {
  makaleId: number;
  makale: Makale;
  yorumlar: Yorum[];
  constructor(
    public apiServis: ApiService,
    public route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.route.params.subscribe(p => {
      if (p.makaleId) {
        this.makaleId = p.makaleId;
        this.MakaleById();
      }
    });
  }

  MakaleById() {
    this.apiServis.MakaleById(this.makaleId).subscribe((d: Makale) => {
      this.makale = d;
      this.MakaleOkunduYap();
      this.YorumListe();
    });
  }
  MakaleOkunduYap() {
    this.makale.Okunma += 1;
    this.apiServis.MakaleDuzenle(this.makale).subscribe();
  }

  YorumListe() {
    this.apiServis.YorumListeByMakaleId(this.makaleId).subscribe((d: Yorum[]) => {
      this.yorumlar = d;
    });
  }
  YorumEkle(yorumMetni: string) {
    var uyeId: number = parseInt(localStorage.getItem("uid"));
    var yorum: Yorum = new Yorum();
    yorum.YorumIcerik = yorumMetni;
    yorum.MakaleId = this.makaleId;
    yorum.UyeId = uyeId;
    yorum.Tarih = new Date();

    this.apiServis.YorumEkle(yorum).subscribe((s: Sonuc) => {
      if (s.islem) {
        this.YorumListe();
      }
    });
  }
}
