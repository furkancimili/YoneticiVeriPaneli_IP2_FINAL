import { Duyuru } from './../../../models/Duyuru';
import { Component, OnInit } from '@angular/core';
import { ApiService } from 'src/app/services/api.service';
import { MatDialog } from '@angular/material/dialog';
import { MyAlertService } from 'src/app/services/myAlert.service';
import { Kategori } from 'src/app/models/Kategori';
import { MatSort } from '@angular/material/sort';
import { ConfirmDialogComponent } from '../../dialogs/confirm-dialog/confirm-dialog.component';
import { DuyuruDialogComponent } from '../../dialogs/duyuru-dialog/duyuru-dialog.component';
import { FormGroup, FormBuilder } from '@angular/forms';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import {ViewChild } from '@angular/core';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource } from '@angular/material/table';
import { Sonuc } from 'src/app/models/Sonuc';
import { ActivatedRoute } from '@angular/router';
@Component({
  selector: 'app-admin-duyuru',
  templateUrl: './admin-duyuru.component.html',
  styleUrls: ['./admin-duyuru.component.scss']
})
export class AdminDuyuruComponent implements OnInit {
  kategoriler: Kategori[];
  duyurular: Duyuru[];
  katId: number;
  uyeId: number;
  dataSource: any;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatSort;
  displayedColumns = ['DuyuruBaslik', 'DuyuruTarih', 'UyeKadi', 'DuyuruOkunma', 'DuyuruDetay'];
  dialogRef: MatDialogRef<DuyuruDialogComponent>;
  dialogRefConfirm: MatDialogRef<ConfirmDialogComponent>;
  constructor(
    public apiServis: ApiService,
    public alert: MyAlertService,
    public matDialog: MatDialog,
    public route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.uyeId = parseInt(localStorage.getItem("uid"));
    this.KategoriListele();

    this.route.params.subscribe(p => {
      if (p.katId) {
        this.katId = parseInt(p.katId);
        this.DuyuruListele();
      }

    });

  }

  KategoriListele() {
    this.apiServis.KategoriListe().subscribe((d: Kategori[]) => {
      this.kategoriler = d;

    });
  }

  DuyuruListele() {
    this.apiServis.DuyuruListeByKatId(this.katId).subscribe((d: Duyuru[]) => {
      this.duyurular = d;
      this.dataSource = new MatTableDataSource(this.duyurular);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
    });
  }

  KategoriSec(katId: number) {
    this.katId = katId;
    this.DuyuruListele();
  }
  Ekle() {
    var yeniKayit: Duyuru = new Duyuru();
    this.dialogRef = this.matDialog.open(DuyuruDialogComponent, {
      width: '800px',
      data: {
        kayit: yeniKayit,
        islem: 'ekle'
      }
    });
    this.dialogRef.afterClosed().subscribe(d => {
      if (d) {

        yeniKayit.DuyuruBaslik = d.DuyuruBaslik;
        yeniKayit.KategoriId = d.KategoriId;
        yeniKayit.DuyuruIcerik = d.DuyuruIcerik;
        yeniKayit.UyeId = this.uyeId;
        yeniKayit.DuyuruTarih = new Date();
        yeniKayit.DuyuruOkunma = 0;
        this.apiServis.DuyuruEkle(yeniKayit).subscribe((s: Sonuc) => {
          this.alert.AlertUygula(s);
          if (s.islem) {
            this.DuyuruListele();
          }
        });
      }
    });
  }
  Duzenle(kayit: Duyuru) {
    this.dialogRef = this.matDialog.open(DuyuruDialogComponent, {
      width: '800px',
      data: {
        kayit: kayit,
        islem: 'duzenle'
      }
    });
    this.dialogRef.afterClosed().subscribe(d => {
      if (d) {
        kayit.DuyuruBaslik = d.DuyuruBaslik;
        kayit.KategoriId = d.KategoriId;
        kayit.DuyuruIcerik = d.DuyuruIcerik;
        this.apiServis.DuyuruDuzenle(kayit).subscribe((s: Sonuc) => {
          this.alert.AlertUygula(s);
          if (s.islem) {
            this.DuyuruListele();
          }
        });
      }
    });
  }
  Detay(kayit: Duyuru) {
    this.dialogRef = this.matDialog.open(DuyuruDialogComponent, {
      width: '800px',
      data: {
        kayit: kayit,
        islem: 'detay'
      }
    });
  }
  Sil(kayit: Duyuru) {
    this.dialogRefConfirm = this.matDialog.open(ConfirmDialogComponent, {
      width: '400px'
    });
    this.dialogRefConfirm.componentInstance.dialogMesaj = kayit.DuyuruBaslik + " Başlıklı Duyuru Silinecektir onaylıyor musunuz?";

    this.dialogRefConfirm.afterClosed().subscribe(d => {
      if (d) {

        this.apiServis.DuyuruSil(kayit.DuyuruId).subscribe((s: Sonuc) => {
          this.alert.AlertUygula(s);
          if (s.islem) {
            this.DuyuruListele();
          }
        });
      }
    });

  }
}
