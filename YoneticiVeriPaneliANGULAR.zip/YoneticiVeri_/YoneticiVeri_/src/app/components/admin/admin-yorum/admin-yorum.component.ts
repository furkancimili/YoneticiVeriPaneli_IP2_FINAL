import { YorumDialogComponent } from './../../dialogs/yorum-dialog/yorum-dialog.component';
import { Yorum } from './../../../models/Yorum';
import { MatSort } from '@angular/material/sort';
import { ConfirmDialogComponent } from './../../dialogs/confirm-dialog/confirm-dialog.component';
import { Sonuc } from './../../../models/Sonuc';
import { MatDialog, MatDialogRef } from '@angular/material/dialog';
import { MyAlertService } from './../../../services/myAlert.service';
import { ApiService } from './../../../services/api.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { MatPaginator } from '@angular/material/paginator';
@Component({
  selector: 'app-admin-yorum',
  templateUrl: './admin-yorum.component.html',
  styleUrls: ['./admin-yorum.component.scss']
})
export class AdminYorumComponent implements OnInit {
  yorumlar: Yorum[];
  dataSource: any;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatSort;
  displayedColumns = ['YorumId','detay'];
  dialogRef: MatDialogRef<YorumDialogComponent>;
  dialogRefConfirm: MatDialogRef<ConfirmDialogComponent>;
  constructor(
    public apiServis: ApiService,
    public alert: MyAlertService,
    public matDialog: MatDialog
  ) { }

  ngOnInit() {
    this.YorumListele();
  }

  YorumListele() {
    this.apiServis.YorumListe().subscribe((d: Yorum[]) => {
      this.yorumlar = d;
      this.dataSource = new MatTableDataSource(this.yorumlar);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
    });
  }
  Ekle() {
    var yeniKayit: Yorum = new Yorum();
    this.dialogRef = this.matDialog.open(YorumDialogComponent, {
      width: '400px',
      data: {
        kayit: yeniKayit,
        islem: 'ekle'
      }
    });
    this.dialogRef.afterClosed().subscribe(d => {
      if (d) {
        this.apiServis.YorumEkle(d).subscribe((s: Sonuc) => {
          this.alert.AlertUygula(s);
          if (s.islem) {
            this.YorumListele();
          }
        });
      }
    });
  }
  Duzenle(kayit: Yorum) {
    this.dialogRef = this.matDialog.open(YorumDialogComponent, {
      width: '400px',
      data: {
        kayit: kayit,
        islem: 'duzenle'
      }
    });
    this.dialogRef.afterClosed().subscribe(d => {
      if (d) {
        kayit.YorumIcerik = d.YorumIcerik;
        this.apiServis.YorumDuzenle(kayit).subscribe((s: Sonuc) => {
          this.alert.AlertUygula(s);
          if (s.islem) {
            this.YorumListele();
          }
        });
      }
    });
  }
  Sil(kayit: Yorum) {
    this.dialogRefConfirm = this.matDialog.open(ConfirmDialogComponent, {
      width: '400px'
    });
    this.dialogRefConfirm.componentInstance.dialogMesaj = kayit.YorumId + " Yorumu Silinecektir onaylıyor musunuz?";

    this.dialogRefConfirm.afterClosed().subscribe(d => {
      if (d) {

        this.apiServis.YorumSil(kayit.YorumId).subscribe((s: Sonuc) => {
          this.alert.AlertUygula(s);
          if (s.islem) {
            this.YorumListele();
          }
        });
      }
    });

  }
}
