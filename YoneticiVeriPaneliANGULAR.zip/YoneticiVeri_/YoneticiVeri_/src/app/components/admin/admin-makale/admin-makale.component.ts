
import { Makale } from './../../../models/Makale';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatDialogRef, MatDialog } from '@angular/material/dialog';
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { MatTableDataSource } from '@angular/material/table';
import { Kategori } from 'src/app/models/Kategori';
import { Sonuc } from 'src/app/models/Sonuc';
import { ApiService } from 'src/app/services/api.service';
import { MyAlertService } from 'src/app/services/myAlert.service';
import { ConfirmDialogComponent } from '../../dialogs/confirm-dialog/confirm-dialog.component';
import { MakaleDialogComponent } from '../../dialogs/makale-dialog/makale-dialog.component';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-admin-makale',
  templateUrl: './admin-makale.component.html',
  styleUrls: ['./admin-makale.component.css']
})
export class AdminMakaleComponent implements OnInit {
  kategoriler: Kategori[];
  makaleler: Makale[];
  katId: number;
  uyeId: number;
  dataSource: any;
  @ViewChild(MatSort) sort: MatSort;
  @ViewChild(MatPaginator) paginator: MatSort;
  displayedColumns = ['Baslik', 'Tarih', 'UyeKadi', 'Okunma', 'detay'];
  dialogRef: MatDialogRef<MakaleDialogComponent>;
  dialogRefConfirm: MatDialogRef<ConfirmDialogComponent>;
  constructor(
    public apiServis: ApiService,
    public alert: MyAlertService,
    public matDialog: MatDialog,
    public route: ActivatedRoute
  ) { }

  ngOnInit() {
    this.uyeId = parseInt(localStorage.getItem("uid"));
    this.KategoriListele();

    this.route.params.subscribe(p => {
      if (p.katId) {
        this.katId = parseInt(p.katId);
        this.MakaleListele();
      }

    });

  }

  KategoriListele() {
    this.apiServis.KategoriListe().subscribe((d: Kategori[]) => {
      this.kategoriler = d;

    });
  }

  MakaleListele() {
    this.apiServis.MakaleListeByKatId(this.katId).subscribe((d: Makale[]) => {
      this.makaleler = d;
      this.dataSource = new MatTableDataSource(this.makaleler);
      this.dataSource.sort = this.sort;
      this.dataSource.paginator = this.paginator;
    });
  }

  KategoriSec(katId: number) {
    this.katId = katId;
    this.MakaleListele();
  }
  Ekle() {
    var yeniKayit: Makale = new Makale();
    this.dialogRef = this.matDialog.open(MakaleDialogComponent, {
      width: '800px',
      data: {
        kayit: yeniKayit,
        islem: 'ekle'
      }
    });
    this.dialogRef.afterClosed().subscribe(d => {
      if (d) {

        yeniKayit.Baslik = d.Baslik;
        yeniKayit.KategoriId = d.KategoriId;
        yeniKayit.Icerik = d.Icerik;
        yeniKayit.UyeId = this.uyeId;
        yeniKayit.Tarih = new Date();
        yeniKayit.Foto = "foto.jpg";
        yeniKayit.Okunma = 0;
        this.apiServis.MakaleEkle(yeniKayit).subscribe((s: Sonuc) => {
          this.alert.AlertUygula(s);
          if (s.islem) {
            this.MakaleListele();
          }
        });
      }
    });
  }
  Duzenle(kayit: Makale) {
    this.dialogRef = this.matDialog.open(MakaleDialogComponent, {
      width: '800px',
      data: {
        kayit: kayit,
        islem: 'duzenle'
      }
    });
    this.dialogRef.afterClosed().subscribe(d => {
      if (d) {
        kayit.Baslik = d.Baslik;
        kayit.KategoriId = d.KategoriId;
        kayit.Icerik = d.Icerik;
        this.apiServis.MakaleDuzenle(kayit).subscribe((s: Sonuc) => {
          this.alert.AlertUygula(s);
          if (s.islem) {
            this.MakaleListele();
          }
        });
      }
    });
  }
  Detay(kayit: Makale) {
    this.dialogRef = this.matDialog.open(MakaleDialogComponent, {
      width: '800px',
      data: {
        kayit: kayit,
        islem: 'detay'
      }
    });
  }
  Sil(kayit: Makale) {
    this.dialogRefConfirm = this.matDialog.open(ConfirmDialogComponent, {
      width: '400px'
    });
    this.dialogRefConfirm.componentInstance.dialogMesaj = kayit.Baslik + " Başlıklı Makale Silinecektir onaylıyor musunuz?";

    this.dialogRefConfirm.afterClosed().subscribe(d => {
      if (d) {

        this.apiServis.MakaleSil(kayit.MakaleId).subscribe((s: Sonuc) => {
          this.alert.AlertUygula(s);
          if (s.islem) {
            this.MakaleListele();
          }
        });
      }
    });

  }
}
