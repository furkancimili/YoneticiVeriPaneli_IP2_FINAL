import { AdminComponent } from './components/admin/admin/admin.component';
import { AdminYorumComponent } from './components/admin/admin-yorum/admin-yorum.component';
import { YorumDialogComponent } from './components/dialogs/yorum-dialog/yorum-dialog.component';
import { UyemakaleComponent } from './components/uyemakale/uyemakale.component';
import { KategoriComponent } from './components/kategori/kategori.component';
import { MakaleComponent } from './components/makale/makale.component';
import { LoginComponent } from './components/login/login.component';
import { MainNavComponent } from './components/main-nav/main-nav.component';
import { AdminUyeComponent } from './components/admin/admin-uye/admin-uye.component';
import { AdminMakaleComponent } from './components/admin/admin-makale/admin-makale.component';
import { AdminKategoriComponent } from './components/admin/admin-kategori/admin-kategori.component';
import { AdminDuyuruComponent } from './components/admin/admin-duyuru/admin-duyuru.component';
import { DuyuruComponent } from './components/duyuru/duyuru.component';
import { UyeDialogComponent } from './components/dialogs/uye-dialog/uye-dialog.component';
import { MakaleDialogComponent } from './components/dialogs/makale-dialog/makale-dialog.component';
import { DuyuruDialogComponent } from './components/dialogs/duyuru-dialog/duyuru-dialog.component';
import { KategoriDialogComponent } from './components/dialogs/kategori-dialog/kategori-dialog.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MaterialModule } from './material.module';
import { AlertDialogComponent } from './components/dialogs/alert-dialog/alert-dialog.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DefaultModule } from './layouts/default/default.module';
import { ReactiveFormsModule } from '@angular/forms';

import { ApiService } from './services/api.service';
import { AuthGuard } from './services/AuthGuard';
import { AuthInterceptor } from './services/AuthInterceptor';
import { SafeHTMLPipe } from './pipes/safeHTML.pipe';
import { MyAlertService } from './services/myAlert.service';
import { HTTP_INTERCEPTORS } from '@angular/common/http';
import { ConfirmDialogComponent } from './components/dialogs/confirm-dialog/confirm-dialog.component';
import { JoditAngularComponent } from 'jodit-angular';
@NgModule({
  declarations: [	
    AppComponent,
    DuyuruComponent,
    MainNavComponent,
    LoginComponent,
    SafeHTMLPipe,
    MakaleComponent,
    KategoriComponent,
    UyemakaleComponent,
    DuyuruComponent,
    JoditAngularComponent,


     //Admin
     AdminComponent,
     AdminDuyuruComponent,
     AdminKategoriComponent,
     AdminMakaleComponent,
     AdminUyeComponent,
     AdminYorumComponent,
   
    

     
      //Dialoglar
      AlertDialogComponent,
      ConfirmDialogComponent,
      KategoriDialogComponent,
      MakaleDialogComponent,
      DuyuruDialogComponent,
      UyeDialogComponent,
      YorumDialogComponent,
   ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    DefaultModule,
    MaterialModule,
    HttpClientModule,
    ReactiveFormsModule,
    
    
    
  
  
  ],
  entryComponents: [
    AlertDialogComponent,
    ConfirmDialogComponent,
    KategoriDialogComponent,
    DuyuruDialogComponent,
    MakaleDialogComponent,
    UyeDialogComponent,
    YorumDialogComponent


    

  ], providers: [MyAlertService, ApiService, SafeHTMLPipe, AuthGuard,
    { provide: HTTP_INTERCEPTORS, useClass: AuthInterceptor, multi: true },
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
